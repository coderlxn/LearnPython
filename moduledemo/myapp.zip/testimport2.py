# -*- coding: utf-8 -*-
# @Time    : 11/20/18 2:11 PM
# @Author  : Jax.Li
# @FileName: testimport2.py
# @Software: PyCharm
# @Blog    ：https://blog.jaxli.com

from moduledemo.testimportall import *

print(blah)
