# -*- coding: utf-8 -*-
# @Time    : 11/20/18 2:38 PM
# @Author  : Jax.Li
# @FileName: __main__.py
# @Software: PyCharm
# @Blog    ：https://blog.jaxli.com


print("run in the module demo application")
